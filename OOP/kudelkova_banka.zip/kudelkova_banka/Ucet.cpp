#include "Ucet.h"



Ucet::Ucet(int cislo_u, Klient* v)
{
	cislo_uctu = cislo_u;
	vlastnik = v;
	stav_uctu = 1000;
}

Ucet::Ucet(int cislo_u, Klient* v, Klient* p)
{
	cislo_uctu = cislo_u;
	vlastnik = v;
	partner = p;
	stav_uctu = 50	;
}

Ucet::Ucet(int cislo_u, Klient* v, double u)
{
	cislo_uctu = cislo_u;
	vlastnik = v;
	urok = u;
	stav_uctu = 0;
}

Ucet::Ucet(int cislo_u, Klient* v, Klient* p, double u)
{
	cislo_uctu = cislo_u;
	vlastnik = v;
	partner = p;
	urok = u;
	stav_uctu = 0;
}

int Ucet::GetCislo_uctu()
{
	return cislo_uctu;
}

double Ucet::GetStav_uctu()
{
	return stav_uctu;
}

double Ucet::GetUrok()
{
	return urok;
}

Klient* Ucet::GetVlastnik()
{
	return vlastnik;
}

Klient* Ucet::GetPartner()
{
	return partner;
}

bool Ucet::Muzu_vybrat(double suma)
{
	if (suma <= stav_uctu)
		return true;
	else return false;
}

void Ucet::Vlozit(double suma)
{
	stav_uctu += suma;
}

bool Ucet::Vybrat(double suma)
{
	if (Muzu_vybrat(suma))
	{
		stav_uctu -= suma;
		return true;
	}
	else return false;
}

void Ucet::Zurocit()
{
	stav_uctu = stav_uctu * (1 + urok);
}