#include "Klient.h"

class Ucet
{
private:
	int cislo_uctu;
	double stav_uctu;
	double urok = 0;

	Klient* vlastnik;
	Klient* partner;

public:
	Ucet(int cislo_u, Klient* v);
	Ucet(int cislo_u, Klient* v, Klient* p);
	Ucet(int cislo_u, Klient* v, double u);
	Ucet(int cislo_u, Klient* v, Klient* p, double u);

	int GetCislo_uctu();
	double GetStav_uctu();
	double GetUrok();
	Klient* GetVlastnik();
	Klient* GetPartner();

	bool Muzu_vybrat(double suma);

	void Vlozit(double suma);
	bool Vybrat(double suma);
	void Zurocit();

};

