#include <string>

using namespace std;

class Klient
{
private:
	int kod;
	string jmeno = "FANTOMAS";


public:
	Klient(string j, int k);

	int GetKod();
	string GetJmeno();
};

