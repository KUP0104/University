#include "Ucet.h"

class Banka
{
private:

	Klient** klienti;
	int pocetKlientu;

	Ucet** ucty;
	int pocetUctu;

	int skutecneKlientu;
	int skutecneUctu;

public:
	Banka(int k, int u);
	~Banka();

	Klient* GetKlient(int k);
	Ucet* GetUcet(int u);
	int Klientu();
	int Uctu();

	Klient* CreateKlient(int k, string j);
	Ucet* CreateUcet(int cislo_u, Klient* k);
	Ucet* CreateUcet(int cislo_u, Klient* k, double ir);
	Ucet* CreateUcet(int cislo_u, Klient* k, Klient *p);
	Ucet* CreateUcet(int cislo_u, Klient* k, Klient *p, double ir);

	void Zuroc();
};

