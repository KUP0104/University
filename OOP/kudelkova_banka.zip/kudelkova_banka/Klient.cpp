#include "Klient.h"

Klient::Klient(string j, int k)
{
	jmeno = j;
	kod = k;
}

int Klient::GetKod()
{
	return kod;
}

string Klient::GetJmeno()
{
	return jmeno;
}
